package com.passportphoto.data.model

import android.graphics.Bitmap
import android.graphics.Rect

data class PassportPhoto(
    val originalBitmap: Bitmap,
    val processedBitmap: Bitmap? = null,
    val faceRect: Rect? = null,
    val standard: CountryStandard = CountryStandard.INDIA,
    val backgroundColor: Int = android.graphics.Color.WHITE,
    val enhancementParams: PhotoEnhancementParams = PhotoEnhancementParams()
)
