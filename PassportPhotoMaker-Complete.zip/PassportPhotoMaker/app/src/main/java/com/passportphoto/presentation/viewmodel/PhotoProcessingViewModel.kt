package com.passportphoto.presentation.viewmodel

import android.graphics.Bitmap
import androidx.lifecycle.ViewModel
import androidx.lifecycle.viewModelScope
import com.passportphoto.data.model.PassportPhoto
import com.passportphoto.data.model.ValidationIssue
import com.passportphoto.domain.usecase.FaceDetectionResult
import com.passportphoto.domain.usecase.FaceDetectionUseCase
import com.passportphoto.utils.BackgroundRemover
import com.passportphoto.utils.ImageProcessor
import com.passportphoto.utils.PDFGenerator
import kotlinx.coroutines.Dispatchers
import kotlinx.coroutines.flow.*
import kotlinx.coroutines.launch
import kotlinx.coroutines.withContext
import java.io.File

class PhotoProcessingViewModel : ViewModel() {
    
    private val detectFaceUseCase = FaceDetectionUseCase()
    private val imageProcessor = ImageProcessor()
    private val backgroundRemover = BackgroundRemover()
    private val pdfGenerator = PDFGenerator()
    
    private val _state = MutableStateFlow<ProcessingState>(ProcessingState.Idle)
    val state: StateFlow<ProcessingState> = _state.asStateFlow()
    
    private val _photo = MutableStateFlow<PassportPhoto?>(null)
    val photo: StateFlow<PassportPhoto?> = _photo.asStateFlow()
    
    fun loadPhoto(bitmap: Bitmap) {
        viewModelScope.launch {
            _state.value = ProcessingState.DetectingFace
            
            when (val result = detectFaceUseCase.detectFace(bitmap)) {
                is FaceDetectionResult.Success -> {
                    _photo.value = PassportPhoto(
                        originalBitmap = bitmap,
                        faceRect = result.face.boundingBox
                    )
                    _state.value = ProcessingState.FaceDetected(result.issues)
                }
                is FaceDetectionResult.NoFaceDetected -> {
                    _state.value = ProcessingState.Error("No face detected. Please ensure your face is clearly visible.")
                }
                is FaceDetectionResult.MultipleFaces -> {
                    _state.value = ProcessingState.Error("Multiple faces detected. Only one person should be in the photo.")
                }
                is FaceDetectionResult.Error -> {
                    _state.value = ProcessingState.Error(result.message)
                }
            }
        }
    }
    
    fun enhancePhoto() {
        viewModelScope.launch {
            _state.value = ProcessingState.Enhancing
            
            val currentPhoto = _photo.value ?: return@launch
            
            val enhanced = withContext(Dispatchers.Default) {
                imageProcessor.enhancePassportPhoto(
                    currentPhoto.originalBitmap,
                    currentPhoto.enhancementParams
                )
            }
            
            _photo.value = currentPhoto.copy(processedBitmap = enhanced)
            _state.value = ProcessingState.Enhanced
        }
    }
    
    fun removeBackground(backgroundColor: Int) {
        viewModelScope.launch {
            _state.value = ProcessingState.RemovingBackground
            
            val currentPhoto = _photo.value ?: return@launch
            val bitmap = currentPhoto.processedBitmap ?: currentPhoto.originalBitmap
            val faceRect = currentPhoto.faceRect ?: return@launch
            
            val result = withContext(Dispatchers.Default) {
                backgroundRemover.removeBackground(bitmap, faceRect, backgroundColor)
            }
            
            _photo.value = currentPhoto.copy(
                processedBitmap = result,
                backgroundColor = backgroundColor
            )
            _state.value = ProcessingState.BackgroundRemoved
        }
    }
    
    fun generatePDF(outputFile: File, showCutLines: Boolean = true) {
        viewModelScope.launch {
            _state.value = ProcessingState.GeneratingPDF
            
            val currentPhoto = _photo.value ?: run {
                _state.value = ProcessingState.Error("No photo to generate PDF")
                return@launch
            }
            
            val bitmap = currentPhoto.processedBitmap ?: currentPhoto.originalBitmap
            
            val success = withContext(Dispatchers.IO) {
                pdfGenerator.generatePrintablePDF(
                    bitmap,
                    currentPhoto.standard,
                    outputFile,
                    showCutLines
                )
            }
            
            if (success) {
                _state.value = ProcessingState.PDFGenerated(outputFile)
            } else {
                _state.value = ProcessingState.Error("Failed to generate PDF")
            }
        }
    }
    
    fun resetState() {
        _state.value = ProcessingState.Idle
        _photo.value = null
    }
}

sealed class ProcessingState {
    object Idle : ProcessingState()
    object DetectingFace : ProcessingState()
    data class FaceDetected(val issues: List<ValidationIssue>) : ProcessingState()
    object Enhancing : ProcessingState()
    object Enhanced : ProcessingState()
    object RemovingBackground : ProcessingState()
    object BackgroundRemoved : ProcessingState()
    object GeneratingPDF : ProcessingState()
    data class PDFGenerated(val file: File) : ProcessingState()
    data class Error(val message: String) : ProcessingState()
}
