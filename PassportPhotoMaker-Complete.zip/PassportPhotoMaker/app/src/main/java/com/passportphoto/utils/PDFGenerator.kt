package com.passportphoto.utils

import android.graphics.*
import android.graphics.pdf.PdfDocument
import com.passportphoto.data.model.CountryStandard
import java.io.File
import java.io.FileOutputStream

class PDFGenerator {
    
    companion object {
        // A4 dimensions at 300 DPI
        private const val A4_WIDTH_PX = 2480  // 210mm
        private const val A4_HEIGHT_PX = 3508 // 297mm
        private const val MARGIN_PX = 118     // 10mm
        private const val SPACING_PX = 59     // 5mm
    }
    
    fun generatePrintablePDF(
        photo: Bitmap,
        standard: CountryStandard,
        outputFile: File,
        showCutLines: Boolean = true
    ): Boolean {
        return try {
            val document = PdfDocument()
            val pageInfo = PdfDocument.PageInfo.Builder(
                A4_WIDTH_PX,
                A4_HEIGHT_PX,
                1
            ).create()
            
            val page = document.startPage(pageInfo)
            val canvas = page.canvas
            
            // White background
            canvas.drawColor(Color.WHITE)
            
            // Calculate photo dimensions
            val photoWidth = standard.getWidthPx()
            val photoHeight = standard.getHeightPx()
            
            // Scale photo to exact size
            val scaledPhoto = Bitmap.createScaledBitmap(photo, photoWidth, photoHeight, true)
            
            // Calculate grid (4 columns × 2 rows = 8 photos)
            val cols = 4
            val rows = 2
            
            val totalWidth = cols * photoWidth + (cols - 1) * SPACING_PX
            val totalHeight = rows * photoHeight + (rows - 1) * SPACING_PX
            
            val startX = (A4_WIDTH_PX - totalWidth) / 2
            val startY = (A4_HEIGHT_PX - totalHeight) / 2
            
            val paint = Paint(Paint.ANTI_ALIAS_FLAG)
            
            // Draw 8 photos
            for (row in 0 until rows) {
                for (col in 0 until cols) {
                    val x = startX + col * (photoWidth + SPACING_PX)
                    val y = startY + row * (photoHeight + SPACING_PX)
                    
                    canvas.drawBitmap(scaledPhoto, x.toFloat(), y.toFloat(), paint)
                    
                    if (showCutLines) {
                        drawCutLines(canvas, x, y, photoWidth, photoHeight)
                    }
                }
            }
            
            // Add title
            val titlePaint = Paint().apply {
                color = Color.DKGRAY
                textSize = 40f
                typeface = Typeface.create(Typeface.DEFAULT, Typeface.BOLD)
                textAlign = Paint.Align.CENTER
            }
            canvas.drawText(
                "Passport Photos - ${standard.displayName}",
                A4_WIDTH_PX / 2f,
                100f,
                titlePaint
            )
            
            document.finishPage(page)
            
            // Write to file
            FileOutputStream(outputFile).use { outputStream ->
                document.writeTo(outputStream)
            }
            
            document.close()
            scaledPhoto.recycle()
            true
        } catch (e: Exception) {
            e.printStackTrace()
            false
        }
    }
    
    private fun drawCutLines(canvas: Canvas, x: Int, y: Int, width: Int, height: Int) {
        val paint = Paint().apply {
            color = Color.LTGRAY
            strokeWidth = 1f
            style = Paint.Style.STROKE
            pathEffect = DashPathEffect(floatArrayOf(10f, 5f), 0f)
        }
        
        val lineLength = 30f
        
        // Corner marks
        // Top-left
        canvas.drawLine(x - lineLength, y.toFloat(), x.toFloat(), y.toFloat(), paint)
        canvas.drawLine(x.toFloat(), y - lineLength, x.toFloat(), y.toFloat(), paint)
        
        // Top-right
        canvas.drawLine((x + width).toFloat(), y.toFloat(), x + width + lineLength, y.toFloat(), paint)
        canvas.drawLine((x + width).toFloat(), y - lineLength, (x + width).toFloat(), y.toFloat(), paint)
        
        // Bottom-left
        canvas.drawLine(x - lineLength, (y + height).toFloat(), x.toFloat(), (y + height).toFloat(), paint)
        canvas.drawLine(x.toFloat(), (y + height).toFloat(), x.toFloat(), y + height + lineLength, paint)
        
        // Bottom-right
        canvas.drawLine((x + width).toFloat(), (y + height).toFloat(), x + width + lineLength, (y + height).toFloat(), paint)
        canvas.drawLine((x + width).toFloat(), (y + height).toFloat(), (x + width).toFloat(), y + height + lineLength, paint)
    }
}
