package com.passportphoto.data.model

enum class CountryStandard(
    val widthMM: Float,
    val heightMM: Float,
    val dpi: Int = 300,
    val displayName: String
) {
    INDIA(35f, 45f, 300, "India (35×45mm)"),
    USA(51f, 51f, 300, "USA (2×2 inch)"),
    UK(35f, 45f, 300, "UK (35×45mm)"),
    CANADA(50f, 70f, 300, "Canada (50×70mm)"),
    SCHENGEN(35f, 45f, 300, "Schengen (35×45mm)");
    
    fun getWidthPx(): Int = ((widthMM / 25.4f) * dpi).toInt()
    fun getHeightPx(): Int = ((heightMM / 25.4f) * dpi).toInt()
}
