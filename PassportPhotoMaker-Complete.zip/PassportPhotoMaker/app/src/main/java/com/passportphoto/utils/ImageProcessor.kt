package com.passportphoto.utils

import android.graphics.Bitmap
import com.passportphoto.data.model.PhotoEnhancementParams
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc

class ImageProcessor {
    
    /**
     * Main enhancement pipeline - professional photo processing
     */
    fun enhancePassportPhoto(
        bitmap: Bitmap,
        params: PhotoEnhancementParams
    ): Bitmap {
        var enhanced = bitmap.copy(Bitmap.Config.ARGB_8888, true)
        
        // Step 1: White balance correction
        enhanced = applyWhiteBalance(enhanced, params.whiteBalance)
        
        // Step 2: Exposure and contrast
        enhanced = adjustExposureContrast(enhanced, params.exposure, params.contrast)
        
        // Step 3: Skin tone normalization
        if (params.skinToneCorrection) {
            enhanced = normalizeSkinTone(enhanced)
        }
        
        // Step 4: Noise reduction (bilateral filter)
        enhanced = reduceNoise(enhanced, params.noiseReduction)
        
        // Step 5: Smart sharpening
        enhanced = applySharpen(enhanced, params.sharpness)
        
        // Step 6: Color depth enhancement
        enhanced = enhanceColorDepth(enhanced)
        
        return enhanced
    }
    
    private fun applyWhiteBalance(bitmap: Bitmap, intensity: Float): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        
        // Convert to LAB color space
        Imgproc.cvtColor(mat, mat, Imgproc.COLOR_RGB2Lab)
        
        val channels = ArrayList<Mat>()
        Core.split(mat, channels)
        
        // Calculate average for A and B channels
        val avgA = Core.mean(channels[1]).`val`[0]
        val avgB = Core.mean(channels[2]).`val`[0]
        
        // Shift towards neutral (128 is neutral in LAB)
        val shiftA = (128 - avgA) * intensity * 0.7
        val shiftB = (128 - avgB) * intensity * 0.7
        
        Core.add(channels[1], Scalar(shiftA), channels[1])
        Core.add(channels[2], Scalar(shiftB), channels[2])
        
        Core.merge(channels, mat)
        Imgproc.cvtColor(mat, mat, Imgproc.COLOR_Lab2RGB)
        
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)
        Utils.matToBitmap(mat, result)
        
        return result
    }
    
    private fun adjustExposureContrast(
        bitmap: Bitmap,
        exposure: Float,
        contrast: Float
    ): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        
        // Apply: output = contrast * input + exposure
        mat.convertTo(mat, -1, contrast.toDouble(), exposure.toDouble())
        
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)
        Utils.matToBitmap(mat, result)
        
        return result
    }
    
    private fun normalizeSkinTone(bitmap: Bitmap): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        
        // Convert to YCrCb for skin detection
        val ycrcb = Mat()
        Imgproc.cvtColor(mat, ycrcb, Imgproc.COLOR_RGB2YCrCb)
        
        // Skin tone range
        val lowerBound = Scalar(0.0, 133.0, 77.0)
        val upperBound = Scalar(255.0, 173.0, 127.0)
        
        val skinMask = Mat()
        Core.inRange(ycrcb, lowerBound, upperBound, skinMask)
        
        // Slight warmth adjustment on skin
        val adjustment = Mat(mat.size(), mat.type(), Scalar(0.0, 2.0, 4.0))
        Core.add(mat, adjustment, mat, skinMask)
        
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)
        Utils.matToBitmap(mat, result)
        
        return result
    }
    
    private fun reduceNoise(bitmap: Bitmap, strength: Float): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        
        val filtered = Mat()
        val d = (strength * 9).toInt().coerceIn(3, 9)
        val sigmaColor = strength * 75
        val sigmaSpace = strength * 75
        
        Imgproc.bilateralFilter(mat, filtered, d, sigmaColor, sigmaSpace)
        
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)
        Utils.matToBitmap(filtered, result)
        
        return result
    }
    
    private fun applySharpen(bitmap: Bitmap, amount: Float): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        
        // Create blurred version
        val blurred = Mat()
        val kernelSize = Size(5.0, 5.0)
        Imgproc.GaussianBlur(mat, blurred, kernelSize, 1.5)
        
        // Unsharp mask
        val diff = Mat()
        Core.subtract(mat, blurred, diff)
        Core.addWeighted(mat, 1.0, diff, amount.toDouble(), 0.0, mat)
        
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)
        Utils.matToBitmap(mat, result)
        
        return result
    }
    
    private fun enhanceColorDepth(bitmap: Bitmap): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        
        // Convert to HSV
        Imgproc.cvtColor(mat, mat, Imgproc.COLOR_RGB2HSV)
        
        val channels = ArrayList<Mat>()
        Core.split(mat, channels)
        
        // Boost saturation slightly
        Core.multiply(channels[1], Scalar(1.15), channels[1])
        
        // Enhance value channel
        channels[2].convertTo(channels[2], -1, 1.05, 0.0)
        
        Core.merge(channels, mat)
        Imgproc.cvtColor(mat, mat, Imgproc.COLOR_HSV2RGB)
        
        val result = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)
        Utils.matToBitmap(mat, result)
        
        return result
    }
}
