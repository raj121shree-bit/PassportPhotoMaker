package com.passportphoto.data.model

data class PhotoEnhancementParams(
    val whiteBalance: Float = 1.0f,
    val exposure: Float = 0f,
    val contrast: Float = 1.05f,
    val sharpness: Float = 0.5f,
    val noiseReduction: Float = 0.3f,
    val skinToneCorrection: Boolean = true
)
