package com.passportphoto.presentation.ui

import android.content.Intent
import android.graphics.Bitmap
import android.graphics.BitmapFactory
import android.graphics.Color
import android.net.Uri
import android.os.Bundle
import android.os.Environment
import android.provider.MediaStore
import android.view.View
import android.widget.Toast
import androidx.activity.result.contract.ActivityResultContracts
import androidx.activity.viewModels
import androidx.appcompat.app.AlertDialog
import androidx.appcompat.app.AppCompatActivity
import androidx.core.content.FileProvider
import androidx.lifecycle.lifecycleScope
import com.google.android.material.dialog.MaterialAlertDialogBuilder
import com.passportphoto.R
import com.passportphoto.databinding.ActivityMainBinding
import com.passportphoto.data.model.ValidationIssue
import com.passportphoto.presentation.viewmodel.PhotoProcessingViewModel
import com.passportphoto.presentation.viewmodel.ProcessingState
import com.permissionx.guolindev.PermissionX
import kotlinx.coroutines.launch
import java.io.File
import java.io.IOException
import java.text.SimpleDateFormat
import java.util.*

class MainActivity : AppCompatActivity() {
    
    private lateinit var binding: ActivityMainBinding
    private val viewModel: PhotoProcessingViewModel by viewModels()
    private var currentPhotoPath: String? = null
    
    private val takePicture = registerForActivityResult(ActivityResultContracts.TakePicture()) { success ->
        if (success) {
            currentPhotoPath?.let { path ->
                val bitmap = BitmapFactory.decodeFile(path)
                viewModel.loadPhoto(bitmap)
            }
        }
    }
    
    private val pickImage = registerForActivityResult(ActivityResultContracts.GetContent()) { uri: Uri? ->
        uri?.let {
            try {
                val bitmap = MediaStore.Images.Media.getBitmap(contentResolver, it)
                viewModel.loadPhoto(bitmap)
            } catch (e: IOException) {
                Toast.makeText(this, "Failed to load image", Toast.LENGTH_SHORT).show()
            }
        }
    }
    
    override fun onCreate(savedInstanceState: Bundle?) {
        super.onCreate(savedInstanceState)
        binding = ActivityMainBinding.inflate(layoutInflater)
        setContentView(binding.root)
        
        setupUI()
        observeState()
        showPrivacyNotice()
    }
    
    private fun setupUI() {
        binding.btnCapture.setOnClickListener {
            requestCameraPermission()
        }
        
        binding.btnGallery.setOnClickListener {
            requestStoragePermission()
        }
        
        binding.btnAutoEnhance.setOnClickListener {
            viewModel.enhancePhoto()
        }
        
        binding.btnRemoveBackground.setOnClickListener {
            showBackgroundColorPicker()
        }
        
        binding.btnGeneratePDF.setOnClickListener {
            generatePDF()
        }
    }
    
    private fun observeState() {
        lifecycleScope.launch {
            viewModel.state.collect { state ->
                when (state) {
                    is ProcessingState.Idle -> {
                        hideProgress()
                        showInitialState()
                    }
                    is ProcessingState.DetectingFace -> {
                        showProgress("Detecting face...")
                    }
                    is ProcessingState.FaceDetected -> {
                        hideProgress()
                        showValidationIssues(state.issues)
                        showEnhancementOptions()
                    }
                    is ProcessingState.Enhancing -> {
                        showProgress("Enhancing photo...")
                    }
                    is ProcessingState.Enhanced -> {
                        hideProgress()
                        Toast.makeText(this@MainActivity, "✨ Photo enhanced!", Toast.LENGTH_SHORT).show()
                    }
                    is ProcessingState.RemovingBackground -> {
                        showProgress("Removing background...")
                    }
                    is ProcessingState.BackgroundRemoved -> {
                        hideProgress()
                        Toast.makeText(this@MainActivity, "Background removed!", Toast.LENGTH_SHORT).show()
                    }
                    is ProcessingState.GeneratingPDF -> {
                        showProgress("Generating PDF...")
                    }
                    is ProcessingState.PDFGenerated -> {
                        hideProgress()
                        showSuccessDialog(state.file)
                    }
                    is ProcessingState.Error -> {
                        hideProgress()
                        showErrorDialog(state.message)
                    }
                }
            }
        }
        
        lifecycleScope.launch {
            viewModel.photo.collect { photo ->
                photo?.let {
                    val bitmap = it.processedBitmap ?: it.originalBitmap
                    binding.imageView.setImageBitmap(bitmap)
                    binding.imageView.visibility = View.VISIBLE
                    binding.placeholderText.visibility = View.GONE
                }
            }
        }
    }
    
    private fun requestCameraPermission() {
        PermissionX.init(this)
            .permissions(android.Manifest.permission.CAMERA)
            .request { allGranted, _, _ ->
                if (allGranted) {
                    launchCamera()
                } else {
                    Toast.makeText(this, "Camera permission required", Toast.LENGTH_SHORT).show()
                }
            }
    }
    
    private fun requestStoragePermission() {
        if (android.os.Build.VERSION.SDK_INT >= android.os.Build.VERSION_CODES.TIRAMISU) {
            PermissionX.init(this)
                .permissions(android.Manifest.permission.READ_MEDIA_IMAGES)
                .request { allGranted, _, _ ->
                    if (allGranted) {
                        pickImage.launch("image/*")
                    } else {
                        Toast.makeText(this, "Storage permission required", Toast.LENGTH_SHORT).show()
                    }
                }
        } else {
            pickImage.launch("image/*")
        }
    }
    
    private fun launchCamera() {
        val photoFile = try {
            createImageFile()
        } catch (e: IOException) {
            Toast.makeText(this, "Error creating file", Toast.LENGTH_SHORT).show()
            return
        }
        
        val photoURI = FileProvider.getUriForFile(
            this,
            "${packageName}.fileprovider",
            photoFile
        )
        
        takePicture.launch(photoURI)
    }
    
    private fun createImageFile(): File {
        val timeStamp = SimpleDateFormat("yyyyMMdd_HHmmss", Locale.getDefault()).format(Date())
        val storageDir = getExternalFilesDir(Environment.DIRECTORY_PICTURES)
        return File.createTempFile("PASSPORT_${timeStamp}_", ".jpg", storageDir).apply {
            currentPhotoPath = absolutePath
        }
    }
    
    private fun showBackgroundColorPicker() {
        val colors = arrayOf("White", "Light Blue", "Light Gray")
        val colorValues = arrayOf(Color.WHITE, Color.rgb(230, 240, 255), Color.rgb(245, 245, 245))
        
        MaterialAlertDialogBuilder(this)
            .setTitle("Select Background Color")
            .setItems(colors) { _, which ->
                viewModel.removeBackground(colorValues[which])
            }
            .show()
    }
    
    private fun generatePDF() {
        val fileName = "passport_photos_${System.currentTimeMillis()}.pdf"
        val outputFile = File(getExternalFilesDir(Environment.DIRECTORY_DOCUMENTS), fileName)
        
        viewModel.generatePDF(outputFile, showCutLines = true)
    }
    
    private fun showValidationIssues(issues: List<ValidationIssue>) {
        if (issues.isEmpty()) return
        
        val message = issues.joinToString("\n") { "⚠️ ${it.message}" }
        MaterialAlertDialogBuilder(this)
            .setTitle("Photo Quality Check")
            .setMessage(message + "\n\nYou can continue, but fixing these issues will improve quality.")
            .setPositiveButton("Continue") { dialog, _ -> dialog.dismiss() }
            .setNegativeButton("Retake") { _, _ -> viewModel.resetState() }
            .show()
    }
    
    private fun showSuccessDialog(file: File) {
        MaterialAlertDialogBuilder(this)
            .setTitle("✅ PDF Generated!")
            .setMessage("Your passport photos are ready:\n${file.name}")
            .setPositiveButton("Share") { _, _ -> sharePDF(file) }
            .setNegativeButton("Done") { dialog, _ -> dialog.dismiss() }
            .show()
    }
    
    private fun sharePDF(file: File) {
        val uri = FileProvider.getUriForFile(this, "${packageName}.fileprovider", file)
        val intent = Intent(Intent.ACTION_SEND).apply {
            type = "application/pdf"
            putExtra(Intent.EXTRA_STREAM, uri)
            addFlags(Intent.FLAG_GRANT_READ_URI_PERMISSION)
        }
        startActivity(Intent.createChooser(intent, "Share PDF"))
    }
    
    private fun showErrorDialog(message: String) {
        MaterialAlertDialogBuilder(this)
            .setTitle("Error")
            .setMessage(message)
            .setPositiveButton("OK") { dialog, _ -> dialog.dismiss() }
            .show()
    }
    
    private fun showInitialState() {
        binding.enhancementCard.visibility = View.GONE
        binding.btnGeneratePDF.visibility = View.GONE
    }
    
    private fun showEnhancementOptions() {
        binding.enhancementCard.visibility = View.VISIBLE
        binding.btnGeneratePDF.visibility = View.VISIBLE
    }
    
    private fun showProgress(message: String) {
        binding.progressBar.visibility = View.VISIBLE
        binding.progressText.text = message
        binding.progressText.visibility = View.VISIBLE
        disableButtons()
    }
    
    private fun hideProgress() {
        binding.progressBar.visibility = View.GONE
        binding.progressText.visibility = View.GONE
        enableButtons()
    }
    
    private fun disableButtons() {
        binding.btnCapture.isEnabled = false
        binding.btnGallery.isEnabled = false
        binding.btnAutoEnhance.isEnabled = false
        binding.btnRemoveBackground.isEnabled = false
        binding.btnGeneratePDF.isEnabled = false
    }
    
    private fun enableButtons() {
        binding.btnCapture.isEnabled = true
        binding.btnGallery.isEnabled = true
        binding.btnAutoEnhance.isEnabled = true
        binding.btnRemoveBackground.isEnabled = true
        binding.btnGeneratePDF.isEnabled = true
    }
    
    private fun showPrivacyNotice() {
        val prefs = getSharedPreferences("privacy", MODE_PRIVATE)
        if (!prefs.getBoolean("notice_shown", false)) {
            MaterialAlertDialogBuilder(this)
                .setTitle("🔒 Your Privacy Matters")
                .setMessage("""
                    ✓ All processing happens on your device
                    ✓ No photos uploaded to the cloud
                    ✓ No face data stored
                    ✓ No tracking or analytics
                    
                    Your photos stay completely private.
                """.trimIndent())
                .setPositiveButton("Got it") { dialog, _ ->
                    prefs.edit().putBoolean("notice_shown", true).apply()
                    dialog.dismiss()
                }
                .setCancelable(false)
                .show()
        }
    }
}
