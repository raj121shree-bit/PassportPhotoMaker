package com.passportphoto.utils

import android.graphics.Bitmap
import android.graphics.Color
import android.graphics.Rect
import org.opencv.android.Utils
import org.opencv.core.*
import org.opencv.imgproc.Imgproc

class BackgroundRemover {
    
    fun removeBackground(
        bitmap: Bitmap,
        faceRect: Rect,
        backgroundColor: Int = Color.WHITE
    ): Bitmap {
        val mat = Mat()
        Utils.bitmapToMat(bitmap, mat)
        
        // Expand face rect to include head and shoulders
        val expandedRect = expandRectangle(faceRect, bitmap.width, bitmap.height)
        
        // Create mask
        val mask = Mat()
        val bgdModel = Mat()
        val fgdModel = Mat()
        
        val rect = org.opencv.core.Rect(
            expandedRect.left,
            expandedRect.top,
            expandedRect.width(),
            expandedRect.height()
        )
        
        // Run GrabCut algorithm
        Imgproc.grabCut(
            mat,
            mask,
            rect,
            bgdModel,
            fgdModel,
            5,
            Imgproc.GC_INIT_WITH_RECT
        )
        
        // Create binary mask
        Core.compare(mask, Scalar(Imgproc.GC_PR_FGD.toDouble()), mask, Core.CMP_EQ)
        
        // Refine edges
        val kernel = Imgproc.getStructuringElement(Imgproc.MORPH_ELLIPSE, Size(3.0, 3.0))
        Imgproc.morphologyEx(mask, mask, Imgproc.MORPH_CLOSE, kernel)
        Imgproc.GaussianBlur(mask, mask, Size(3.0, 3.0), 0.0)
        
        // Create background
        val background = Mat(mat.size(), mat.type(), colorToScalar(backgroundColor))
        
        // Composite
        val result = Mat()
        mat.copyTo(result, mask)
        background.copyTo(result, Core.bitwise_not(mask, Mat()))
        
        val resultBitmap = Bitmap.createBitmap(bitmap.width, bitmap.height, bitmap.config)
        Utils.matToBitmap(result, resultBitmap)
        
        return resultBitmap
    }
    
    private fun expandRectangle(rect: Rect, maxWidth: Int, maxHeight: Int): Rect {
        val expansion = 0.4f
        val newWidth = (rect.width() * (1 + expansion)).toInt()
        val newHeight = (rect.height() * (1 + 2 * expansion)).toInt()
        
        val newLeft = (rect.centerX() - newWidth / 2).coerceIn(0, maxWidth)
        val newTop = (rect.centerY() - newHeight / 2).coerceIn(0, maxHeight)
        val newRight = (newLeft + newWidth).coerceIn(0, maxWidth)
        val newBottom = (newTop + newHeight).coerceIn(0, maxHeight)
        
        return Rect(newLeft, newTop, newRight, newBottom)
    }
    
    private fun colorToScalar(color: Int): Scalar {
        return Scalar(
            Color.red(color).toDouble(),
            Color.green(color).toDouble(),
            Color.blue(color).toDouble()
        )
    }
}
