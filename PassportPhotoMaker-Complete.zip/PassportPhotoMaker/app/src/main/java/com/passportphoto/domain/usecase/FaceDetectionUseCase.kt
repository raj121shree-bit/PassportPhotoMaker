package com.passportphoto.domain.usecase

import android.graphics.Bitmap
import com.google.mlkit.vision.common.InputImage
import com.google.mlkit.vision.face.Face
import com.google.mlkit.vision.face.FaceDetection
import com.google.mlkit.vision.face.FaceDetectorOptions
import com.passportphoto.data.model.ValidationIssue
import kotlin.coroutines.resume
import kotlin.coroutines.suspendCoroutine

class FaceDetectionUseCase {
    
    private val detector = FaceDetection.getClient(
        FaceDetectorOptions.Builder()
            .setPerformanceMode(FaceDetectorOptions.PERFORMANCE_MODE_ACCURATE)
            .setLandmarkMode(FaceDetectorOptions.LANDMARK_MODE_ALL)
            .setClassificationMode(FaceDetectorOptions.CLASSIFICATION_MODE_ALL)
            .setMinFaceSize(0.15f)
            .build()
    )
    
    suspend fun detectFace(bitmap: Bitmap): FaceDetectionResult = suspendCoroutine { cont ->
        val image = InputImage.fromBitmap(bitmap, 0)
        
        detector.process(image)
            .addOnSuccessListener { faces ->
                when {
                    faces.isEmpty() -> cont.resume(FaceDetectionResult.NoFaceDetected)
                    faces.size > 1 -> cont.resume(FaceDetectionResult.MultipleFaces)
                    else -> {
                        val face = faces[0]
                        val validation = validateFace(face, bitmap)
                        cont.resume(FaceDetectionResult.Success(face, validation))
                    }
                }
            }
            .addOnFailureListener { e ->
                cont.resume(FaceDetectionResult.Error(e.message ?: "Unknown error"))
            }
    }
    
    private fun validateFace(face: Face, bitmap: Bitmap): List<ValidationIssue> {
        val issues = mutableListOf<ValidationIssue>()
        
        // Check face size (should be 50-85% of photo height)
        val faceHeight = face.boundingBox.height()
        val imageHeight = bitmap.height
        val faceRatio = faceHeight.toFloat() / imageHeight
        
        when {
            faceRatio < 0.5f -> issues.add(ValidationIssue.FACE_TOO_SMALL)
            faceRatio > 0.85f -> issues.add(ValidationIssue.FACE_TOO_LARGE)
        }
        
        // Check eyes open
        face.leftEyeOpenProbability?.let { leftEye ->
            face.rightEyeOpenProbability?.let { rightEye ->
                if (leftEye < 0.5f || rightEye < 0.5f) {
                    issues.add(ValidationIssue.EYES_CLOSED)
                }
            }
        }
        
        // Check head rotation
        val rotY = face.headEulerAngleY
        val rotZ = face.headEulerAngleZ
        
        if (Math.abs(rotY) > 10 || Math.abs(rotZ) > 10) {
            issues.add(ValidationIssue.HEAD_TILTED)
        }
        
        return issues
    }
}

sealed class FaceDetectionResult {
    data class Success(val face: Face, val issues: List<ValidationIssue>) : FaceDetectionResult()
    object NoFaceDetected : FaceDetectionResult()
    object MultipleFaces : FaceDetectionResult()
    data class Error(val message: String) : FaceDetectionResult()
}
