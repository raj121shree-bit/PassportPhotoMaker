package com.passportphoto

import android.app.Application
import org.opencv.android.OpenCVLoader

class PassportPhotoApp : Application() {
    
    override fun onCreate() {
        super.onCreate()
        
        // Initialize OpenCV
        if (!OpenCVLoader.initDebug()) {
            android.util.Log.e("OpenCV", "Unable to load OpenCV!")
        } else {
            android.util.Log.d("OpenCV", "OpenCV loaded successfully")
        }
    }
}
