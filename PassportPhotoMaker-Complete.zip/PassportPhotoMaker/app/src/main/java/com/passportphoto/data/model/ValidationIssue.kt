package com.passportphoto.data.model

enum class ValidationIssue(val message: String) {
    FACE_TOO_SMALL("Face is too small - move closer"),
    FACE_TOO_LARGE("Face is too large - move back"),
    EYES_CLOSED("Eyes appear to be closed"),
    HEAD_TILTED("Head is tilted - keep straight"),
    POOR_LIGHTING("Lighting may be insufficient"),
    MULTIPLE_FACES("Multiple faces detected"),
    NO_FACE("No face detected")
}
